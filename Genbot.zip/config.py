PREFIX = "-"
GUILD_ID =  # Gen Guild ID
OWNER_IDS = [] # List of owner IDs
DASHBOARD_URL = "" # Base URL of your dashboard
DASHBOARD_PORT =  # Port for the administrative panel

DISCORD_CLIENT_ID = "" # Gen Client ID
DISCORD_CLIENT_SECRET = "" # Gen Client Secret
DISCORD_REDIRECT_URI = f"{DASHBOARD_URL}/api/auth/callback"
JWT_SECRET = "Add_Your_JWT_Secret_Here"

VOUCH_BAN_DURATION = 172800 # 2 Days
VOUCH_CHANNEL_ID = 

"""
Project Name: FeroX Gen
Creator: FeroX Team
Discord Server: https://discord.gg/3BXpr66nuT
"""
